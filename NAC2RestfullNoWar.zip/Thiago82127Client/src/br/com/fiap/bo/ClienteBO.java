package br.com.fiap.bo;

import br.com.fiap.repository.Servico;
import br.com.fiap.to.ClienteTO;

public class ClienteBO {

	private Servico servico = null;
	
	public ClienteTO[] listagem() {
		servico = new Servico();
		return servico.getService();
	}
	
	public ClienteTO listagem(int cod) {
		servico = new Servico();
		return servico.getService(cod);
	}
	
	public void excluir(int cod) {
		servico = new Servico();
		servico.deleteService(cod);
	}
	
	public void atualizar(ClienteTO cliente) {
		servico = new Servico();
		servico.putService(cliente, cliente.getCodigo());
	}
	
	public void cadastrar(ClienteTO cliente) {
		servico = new Servico();
		servico.postService(cliente);
	}
}
