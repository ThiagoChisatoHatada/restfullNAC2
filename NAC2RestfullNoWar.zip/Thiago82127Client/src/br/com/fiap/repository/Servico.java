package br.com.fiap.repository;

import java.net.URI;

import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import br.com.fiap.to.ClienteTO;

public class Servico {

	public Client client = Client.create();
	public WebResource resource = null;
	public ClientResponse response = null;

	public ClienteTO[] getService() {
		resource = client.resource("http://localhost:8080/Thiago82127Server/rest/cliente");
		response = resource.accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);

		if(response.getStatus()==200) {
			return response.getEntity(ClienteTO[].class);
		}else {
			return null;
		}
	}

	public ClienteTO getService(int cod) {

		resource=client.resource("http://localhost:8080/Thiago82127Server/rest/cliente/"+cod);
		response = resource.accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);

		if(response.getStatus()==200) {
			return response.getEntity(ClienteTO.class);
		}else {
			return null;
		}
	}

	public URI postService(ClienteTO cliente) {
		resource = client.resource("http://localhost:8080/Thiago82127Server/rest/cliente/");
		response = resource.type("application/json").post(ClientResponse.class, cliente);

		if(response.getStatus()==200) {
			return response.getLocation();
		}else {
			return null;
		}
	}

	public int putService(ClienteTO cliente, int cod) {

		resource=client.resource("http://localhost:8080/Thiago82127Server/rest/cliente/"+cod);
		response = resource.accept("application/json").put(ClientResponse.class, cliente);

		if(response.getStatus()==200) {
			return response.getStatus();
		}else {
			return response.getStatus();
		}
	}
	
	public int deleteService(int cod) {

		resource=client.resource("http://localhost:8080/Thiago82127Server/rest/cliente/"+cod);
		response = resource.delete(ClientResponse.class);

		if(response.getStatus()==204) {
			return response.getStatus();
		}else {
			return response.getStatus();
		}
	}
	
	public static void main(String[] args) {
		Servico servico = new Servico();
		
		for(ClienteTO c: servico.getService()) {
			System.out.println("Cliente:"+c.getNome());
			System.out.println("Data:"+c.getDataVenda());
			System.out.println("Descricao"+c.getDescricao());
			System.out.println("Descricao"+c.getValor());
			System.out.println("Pago:"+c.getPago());
		}
	}
}
