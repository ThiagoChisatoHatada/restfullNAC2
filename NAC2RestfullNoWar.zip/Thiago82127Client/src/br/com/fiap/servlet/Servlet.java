package br.com.fiap.servlet;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.fiap.bo.ClienteBO;
import br.com.fiap.to.ClienteTO;

@WebServlet(urlPatterns = {"/listagem","/listar","/cadastrar","/atualizar","/excluir"})
public class Servlet extends HttpServlet{

	private static final long serialVersionUID = 1L;
	private ClienteBO cbo = new ClienteBO();
	private ClienteTO cliente = null;
	
	public Servlet() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
		
		if(req.getRequestURI().equals("/Thiago82127Client/listagem")) {
			
			listagem(req, resp);
		}else if(req.getRequestURI().equals("/Thiago82127Client/listar")){
			
			listar(req, resp);
		}else if(req.getRequestURI().equals("/Thiago82127Client/excluir")){
			
			excluir(req, resp);
		}else if(req.getRequestURI().equals("/Thiago82127Client/atualizar")){
			
			atualizar(req, resp);
		}else if(req.getRequestURI().equals("/Thiago82127Client/cadastrar")){
			
			cadastrar(req, resp);
		}
		
	}
	
		protected void listagem(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
			
			ClienteTO[] cto = cbo.listagem();
			
			req.setAttribute("listaDeCliente", cto);
			
			req.setAttribute("controle", "lista-cliente");
			
			req.setAttribute("actionForm", "cadastrar");
			
			req.getRequestDispatcher("index.jsp").forward(req, resp);
		}
		
		protected void listar(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
			
			int cod  = Integer.parseInt(req.getParameter("codigoCliente"));
			
			ClienteTO cto = cbo.listagem(cod);
			
			req.setAttribute("ClienteObj", cto);
			
			req.setAttribute("actionForm", "atualizar");
			
			req.getRequestDispatcher("index.jsp").forward(req, resp);
		}
	
		protected void excluir(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
			
			int cod = Integer.parseInt(req.getParameter("codigoCliente"));
			
			cbo.excluir(cod);
			
			req.setAttribute("controle", "lista-cliente");
			
			req.setAttribute("actionForm", "cadastrar");
			
			req.getRequestDispatcher("listagem").forward(req, resp);;
		}
		
		protected void atualizar(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
			String novaData = req.getParameter("txtDataVenda");
			Date date;
			try {
				date = new SimpleDateFormat("dd/MM/yyyy").parse(novaData);
				cliente = new ClienteTO();
				cliente.setNome(req.getParameter("txtNome"));
				cliente.setDataVenda(date);
				cliente.setDescricao(req.getParameter("txtDesc"));
				cliente.setValor(Double.parseDouble(req.getParameter("txtValor")));
				cliente.setPago(req.getParameter("txtPago"));
				cbo = new ClienteBO();
				cbo.atualizar(cliente);
				
				req.setAttribute("controle", "lista-cliente");
				
				req.setAttribute("actionForm", "adicionar");
				
				req.getRequestDispatcher("listagem").forward(req, resp);
			} catch (ParseException e) {
				
				e.printStackTrace();
			}	
		}
		
		protected void cadastrar(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
			String novaData = req.getParameter("txtDataVenda");
			Date date;
			try {
				date = new SimpleDateFormat("dd/MM/yyyy").parse(novaData);
				cliente = new ClienteTO();
				cliente.setNome(req.getParameter("txtNome"));
				cliente.setDataVenda(date);
				cliente.setDescricao(req.getParameter("txtDesc"));
				cliente.setValor(Double.parseDouble(req.getParameter("txtValor")));
				cliente.setPago(req.getParameter("txtPago"));
				cbo = new ClienteBO();
				cbo.cadastrar(cliente);
				
				req.setAttribute("controle", "lista-cliente");
				
				req.setAttribute("actionForm", "adicionar");
				
				req.getRequestDispatcher("listagem").forward(req, resp);
			} catch (ParseException e) {
				
				e.printStackTrace();
			}	
		}
}
