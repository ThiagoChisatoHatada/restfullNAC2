package br.com.fiap.bo;

import java.util.List;

import br.com.fiap.dao.ClienteDAO;
import br.com.fiap.to.ClienteTO;

public class ClienteBO {

	private ClienteDAO cda = null;
	
	public List<ClienteTO> listagem(){
		cda = new ClienteDAO();
		
		return cda.select();
	}
	
	public ClienteTO listagem(int cod) {
		cda = new ClienteDAO();
		
		return cda.select(cod);
	}
	
	public boolean cadastrarCliente(ClienteTO cliente) {
		cda = new ClienteDAO();
		
		return cda.insert(cliente);
	}
	
	public boolean atualizarCliente(ClienteTO cliente) {
		cda = new ClienteDAO();
		
		return cda.update(cliente);
	}
	
	public void excluir(int cod) {
		cda = new ClienteDAO();
		cda.delete(cod);
	}
}
