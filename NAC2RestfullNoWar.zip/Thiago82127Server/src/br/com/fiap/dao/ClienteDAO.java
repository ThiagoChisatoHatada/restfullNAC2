package br.com.fiap.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import br.com.fiap.to.ClienteTO;

public class ClienteDAO {

	public static List<ClienteTO> listaClienteTO = null;
	
	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	
	Date data = null;
	public ClienteDAO() {
		
		ClienteTO cto = new ClienteTO();
		cto.setCodigo(1);
		cto.setNome("Alexandre");
		try {
			data = sdf.parse("16/05/2020");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cto.setDataVenda(data);
		cto.setDescricao("teste");
		cto.setValor(100.00);
		cto.setPago("Sim");
		
		cto = new ClienteTO();
		cto.setCodigo(2);
		cto.setNome("Joao");
		try {
			data = sdf.parse("01/03/2020");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cto.setDataVenda(data);
		cto.setDescricao("teste");
		cto.setPago("Nao");
		
		cto = new ClienteTO();
		cto.setCodigo(3);
		cto.setNome("Andre");
		try {
			data = sdf.parse("15/04/2020");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cto.setDataVenda(data);
		cto.setDescricao("teste");
		cto.setValor(1470.00);
		cto.setPago("Sim");
		
		cto = new ClienteTO();
		cto.setCodigo(4);
		cto.setNome("Tomaz");
		try {
			data = sdf.parse("01/02/2020");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cto.setDataVenda(data);
		cto.setDescricao("teste");
		cto.setValor(666.99);
		cto.setPago("Nao");
		
		cto = new ClienteTO();
		cto.setCodigo(5);
		cto.setNome("Emerson");
		try {
			data = sdf.parse("27/02/2020");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cto.setDataVenda(data);
		cto.setDescricao("teste");
		cto.setValor(900.00);
		cto.setPago("Sim");
		
		cto = new ClienteTO();
		cto.setCodigo(6);
		cto.setNome("Marcia");
		try {
			data = sdf.parse("01/04/2020");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cto.setDataVenda(data);
		cto.setDescricao("teste");
		cto.setValor(207.54);
		cto.setPago("Sim");
		
		cto = new ClienteTO();
		cto.setCodigo(7);
		cto.setNome("Helena");
		try {
			data = sdf.parse("27/01/2020");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cto.setDataVenda(data);
		cto.setDescricao("teste");
		cto.setValor(573.96);
		cto.setPago("Nao");
		
		cto = new ClienteTO();
		cto.setCodigo(8);
		cto.setNome("Juliana");
		try {
			data = sdf.parse("05/01/2020");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cto.setDataVenda(data);
		cto.setDescricao("teste");
		cto.setValor(97.82);
		cto.setPago("Sim");
		
		cto = new ClienteTO();
		cto.setCodigo(9);
		cto.setNome("Mateus");
		try {
			data = sdf.parse("09/03/2020");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cto.setDataVenda(data);
		cto.setDescricao("teste");
		cto.setValor(473.02);
		cto.setPago("Nao");
		
		cto = new ClienteTO();
		cto.setCodigo(10);
		cto.setNome("Bia");
		try {
			data = sdf.parse("30/04/2020");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cto.setDataVenda(data);
		cto.setDescricao("teste");
		cto.setValor(1000.00);
		cto.setPago("Nao");
	}
	
	public List<ClienteTO> select(){
		return listaClienteTO;
	}
	
	public ClienteTO select (int cod) {
		for(int i=0; i<listaClienteTO.size();i++) {
			if(listaClienteTO.get(i).getCodigo() == cod) {
				return listaClienteTO.get(i);
			}
		}
		return null;
	}
	
	public boolean insert(ClienteTO cliente) {

		if(cliente != null) {
			cliente.setCodigo((listaClienteTO.get(listaClienteTO.size()-1).getCodigo()+1));
			return listaClienteTO.add(cliente);
		}
		return false;
	}
	
	public boolean update(ClienteTO cliente) {
		if(cliente != null) {
			for(int i=0; i<listaClienteTO.size(); i++) {
				
				if(listaClienteTO.get(i).getCodigo() == cliente.getCodigo()) {
					listaClienteTO.set(i, cliente);
					return true;
				}
			}
		}
		return false;
	}
	public void delete (int cod) {
		for (int i = 0; i<listaClienteTO.size(); i++) {
			
			if(listaClienteTO.get(i).getCodigo() == cod) {
				listaClienteTO.remove(i);
			}
		}
	}
}
