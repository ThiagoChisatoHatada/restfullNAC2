package br.com.fiap.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import br.com.fiap.bo.ClienteBO;
import br.com.fiap.to.ClienteTO;

@Path("/cliente")
public class ClienteResource {

	private ClienteBO clienteBO = new ClienteBO();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<ClienteTO> buscar(){
		
		return clienteBO.listagem();
	}
	
	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public ClienteTO buscar(@PathParam("id")int cod) {
		
		return clienteBO.listagem(cod);
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response cadastrar (ClienteTO cliente, @Context UriInfo urInfo) {
		clienteBO.cadastrarCliente(cliente);
		UriBuilder builder = urInfo.getAbsolutePathBuilder();
		builder.path(Integer.toString(cliente.getCodigo()));
		return Response.created(builder.build()).build();
	}
	
	@PUT
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response atualizar (ClienteTO cliente, @PathParam("id") int cod) {
		cliente.setCodigo(cod);
		clienteBO.atualizarCliente(cliente);
		return Response.ok().build();
	}
	
	@DELETE
	@Path("/{id}")
	public void remorver(@PathParam("id")int cod) {
		clienteBO.excluir(cod);
	}
}
