package br.com.fiap.to;

import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ClienteTO {

	private int codigo;
	private String nome;
	private Date dataVenda;
	private String descricao;
	private double valor;
	private String pago;
	
	public ClienteTO() {
		super();
	}

	public ClienteTO(int codigo, String nome, Date dataVenda, String descricao, double valor, String pago) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.dataVenda = dataVenda;
		this.descricao = descricao;
		this.valor = valor;
		this.pago = pago;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Date getDataVenda() {
		return dataVenda;
	}

	public void setDataVenda(Date data) {
		this.dataVenda = data;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public String getPago() {
		return pago;
	}

	public void setPago(String pago) {
		this.pago = pago;
	}
	
	
}
